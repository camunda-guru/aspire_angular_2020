import { Component } from '@angular/core';

import { fadeInAnimation } from '../_animations/index';

@Component({

    templateUrl: './app/home/home.component.html',
    animations: [fadeInAnimation],
    host: { '[@fadeInAnimation]': '' }
})

export class HomeComponent {
}