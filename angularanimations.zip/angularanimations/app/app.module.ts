import {BrowserModule} from "@angular/platform-browser";
import {NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';

import {PopOverComponent} from "./app.popovercomponent";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { AppRoutingModule, routedComponents } from './app-routing.module';
import { ProductService, PubSubService } from './_services/index';

@NgModule({
  imports:[BrowserModule,BrowserAnimationsModule,FormsModule,
      AppRoutingModule,

  ],
  declarations:[PopOverComponent,AppComponent,
      routedComponents
  ],

providers: [
    ProductService,
    PubSubService
],

    bootstrap:[PopOverComponent]

})
export class AppModule{

}

